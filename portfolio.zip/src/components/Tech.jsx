import React from 'react'

const Tech = () => {
  return (
    <div>Tech</div>
  )
}

export default Tech